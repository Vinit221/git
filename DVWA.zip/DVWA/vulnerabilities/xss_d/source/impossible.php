<?php

# Don't need to do anything, protection handled on the client side

?>
