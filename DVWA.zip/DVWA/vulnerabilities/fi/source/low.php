<?php

// The page we wish to display
$file = $_GET[ 'page' ];

?>
